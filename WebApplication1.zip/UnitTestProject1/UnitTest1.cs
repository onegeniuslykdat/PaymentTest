using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Net;
using System.Net.Http;
using WebApplication1;
using WebApplication1.Controllers;
using WebApplication1.Controllers.Services;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestCreditCardCheck()
        {
            IntegratedPaymentServices integratedPaymentServices = new IntegratedPaymentServices();

            Assert.AreEqual(false, integratedPaymentServices.ValidateCreditCard("111231122"));
        }

        [TestMethod]
        public void TestExpirationDateCheck()
        {
            IntegratedPaymentServices integratedPaymentServices = new IntegratedPaymentServices();

            Assert.AreEqual(false, integratedPaymentServices.ValidateExpirationDate(DateTime.Now));
        }

        [TestMethod]
        public void TestPayment()
        {
            PaymentController pcontroller = new PaymentController();

            string CCN = "12234567890";
            string CardHolder = "Anthony";
            DateTime ExpDate = DateTime.Now;
            String SecurityCode = "123";
            Decimal Amount = 45000;

            HttpResponseMessage responseMessage = new HttpResponseMessage();
            responseMessage.StatusCode = HttpStatusCode.BadRequest;

            Assert.AreEqual(responseMessage.StatusCode, pcontroller.PostProcessPayment(CCN, CardHolder, ExpDate, SecurityCode, Amount));
        }
    }
}
