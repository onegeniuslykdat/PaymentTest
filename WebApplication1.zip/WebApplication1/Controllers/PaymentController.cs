﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication1.Controllers.Services;
using WebApplication1.DbContexts;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PaymentController : ControllerBase
    {
        private readonly ILogger<PaymentController> _logger;

        public PaymentController(ILogger<PaymentController> logger)
        {
            _logger = logger;
        }

        public PaymentController()
        {
        }

        public HttpResponseMessage PostProcessPayment(string CCN, string CardHolder, DateTime ExpirationDate, string SecurityCode, decimal Amount)
        {
            PaymentDbContext paymentDbContext = new PaymentDbContext();
            IntegratedPaymentServices integratedPaymentServices = new IntegratedPaymentServices();

            HttpResponseMessage responseMessage = new HttpResponseMessage();

            int trials = 1;
            try
            {            
            string newid = DateTime.Now.Day.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + CCN.Substring(0, 5);
            int transactionid = int.Parse(newid);

           if (integratedPaymentServices.ValidateCreditCard(CCN))
            {
                if (integratedPaymentServices.ValidateExpirationDate(ExpirationDate))
                {
                  if (integratedPaymentServices.ProcessPayment(CCN, CardHolder, ExpirationDate, SecurityCode, Amount, trials, transactionid))
                    {
                        responseMessage.StatusCode = HttpStatusCode.OK;
                        responseMessage.Content = new StringContent(transactionid.ToString());
                        return responseMessage;
                    }
                  else
                    {
                        trials += 1;
                            responseMessage.StatusCode = HttpStatusCode.InternalServerError;
                        responseMessage.Content = new StringContent("Something went wrong.");
                        return responseMessage;
                    }
                }
                else
                    {
                        responseMessage.StatusCode = HttpStatusCode.BadRequest;
                        responseMessage.Content = new StringContent("Please check your details.");
                        return responseMessage;
                    }
            }
           else
                {
                    responseMessage.StatusCode = HttpStatusCode.BadRequest;
                    responseMessage.Content = new StringContent("Please check your details.");
                    return responseMessage;
                }

            }
            catch (Exception)
            {
                responseMessage.StatusCode = HttpStatusCode.InternalServerError;
                responseMessage.Content = new StringContent("Something went wrong");
                return responseMessage;
            }
        }
    }
}
