﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Services
{
    interface PremiumPaymentService
    {
        public bool ProcessPremiumPayment(int TransactionID, int PaymentTrials, decimal Amount);
    }
}
