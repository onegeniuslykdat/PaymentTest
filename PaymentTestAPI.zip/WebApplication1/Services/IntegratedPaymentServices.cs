﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WebApplication1.DbContexts;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers.Services
{
    public class IntegratedPaymentServices : ICheapPaymentGateway, IExpensivePaymentGateway, PremiumPaymentService
    {
        public IntegratedPaymentServices() { }

        public IntegratedPaymentServices _IntegratedPaymentServices = new IntegratedPaymentServices();

        public bool ValidateCreditCard(string creditCardNumber)
        {
            Regex expression = new Regex(@"^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$");

            //Return if it was a match or not
            return expression.IsMatch(creditCardNumber);
        }

        public bool ValidateExpirationDate(DateTime ExpirationDate)
        {
            if (ExpirationDate > DateTime.Now)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public bool ProcessCheapPayment(int TransactionID, int PaymentTrials, decimal Amount)
        {
            Random n = new Random(PaymentTrials);
            return n.Next() % 2 is 0;
        }

       public bool ProcessExpensivePayment(int TransactionID, int PaymentTrials, decimal Amount)
        {
            Random n = new Random(PaymentTrials);
            return n.Next() % 2 is 0;
        }

        public bool ProcessPremiumPayment(int TransactionID, int PaymentTrials, decimal Amount)
        {
            Random n = new Random(PaymentTrials);
            return n.Next() % 2 is 0;
        }



        public bool ProcessPayment(string CCN, string CardHolder, DateTime ExpirationDate, string SecurityCode, decimal Amount, int PaymentTrials, int TransactionID)
        {
            PaymentDbContext paymentDbContext = new PaymentDbContext();
            Payment payment = new Payment();
            PaymentSummary paymentSummary = new PaymentSummary();

            if (Amount >= 0 && Amount <= 20)
            {
                if (ProcessCheapPayment(TransactionID, PaymentTrials, Amount))
                {
                    // add to database
                    payment.Amount = Amount;
                    payment.CardHolder = CardHolder;
                    payment.CreditCardNumber = CCN;
                    payment.ExpirationDate = ExpirationDate;
                    payment.TransactionID = TransactionID;
                    payment.SecurityCode = SecurityCode;

                    paymentSummary.TransactionID = TransactionID;
                    paymentSummary.PaymentState = "Processed";

                    paymentDbContext.payments.Add(payment);
                    paymentDbContext.paymentsSummary.Add(paymentSummary);

                    return true;
                }
                else
                {
                    // add to database
                    payment.Amount = Amount;
                    payment.CardHolder = CardHolder;
                    payment.CreditCardNumber = CCN;
                    payment.ExpirationDate = ExpirationDate;
                    payment.TransactionID = TransactionID;
                    payment.SecurityCode = SecurityCode;

                    paymentSummary.TransactionID = TransactionID;
                    paymentSummary.PaymentState = "Failed";

                    paymentDbContext.payments.Add(payment);
                    paymentDbContext.paymentsSummary.Add(paymentSummary);

                    return false;
                }
            }
            else if(Amount >= 21 && Amount <= 500)
            {
                if (_IntegratedPaymentServices is IExpensivePaymentGateway)
                {
                    if (ProcessExpensivePayment(TransactionID, PaymentTrials, Amount))
                    {
                        // add to database
                        payment.Amount = Amount;
                        payment.CardHolder = CardHolder;
                        payment.CreditCardNumber = CCN;
                        payment.ExpirationDate = ExpirationDate;
                        payment.TransactionID = TransactionID;
                        payment.SecurityCode = SecurityCode;

                        paymentSummary.TransactionID = TransactionID;
                        paymentSummary.PaymentState = "Processed";

                        paymentDbContext.payments.Add(payment);
                        paymentDbContext.paymentsSummary.Add(paymentSummary);

                        return true;
                    }
                    else
                    {
                        // add to database
                        payment.Amount = Amount;
                        payment.CardHolder = CardHolder;
                        payment.CreditCardNumber = CCN;
                        payment.ExpirationDate = ExpirationDate;
                        payment.TransactionID = TransactionID;
                        payment.SecurityCode = SecurityCode;

                        paymentSummary.TransactionID = TransactionID;
                        paymentSummary.PaymentState = "Failed";

                        paymentDbContext.payments.Add(payment);
                        paymentDbContext.paymentsSummary.Add(paymentSummary);

                        return false;
                    }
                }
                else
                {
                    if (PaymentTrials < 1)
                    {
                        if (ProcessCheapPayment(TransactionID, PaymentTrials, Amount))
                        {
                            // add to database
                            payment.Amount = Amount;
                            payment.CardHolder = CardHolder;
                            payment.CreditCardNumber = CCN;
                            payment.ExpirationDate = ExpirationDate;
                            payment.TransactionID = TransactionID;
                            payment.SecurityCode = SecurityCode;

                            paymentSummary.TransactionID = TransactionID;
                            paymentSummary.PaymentState = "Processed";

                            paymentDbContext.payments.Add(payment);
                            paymentDbContext.paymentsSummary.Add(paymentSummary);

                            return true;
                        }
                        else
                        {
                            // add to database
                            payment.Amount = Amount;
                            payment.CardHolder = CardHolder;
                            payment.CreditCardNumber = CCN;
                            payment.ExpirationDate = ExpirationDate;
                            payment.TransactionID = TransactionID;
                            payment.SecurityCode = SecurityCode;

                            paymentSummary.TransactionID = TransactionID;
                            paymentSummary.PaymentState = "Failed";

                            paymentDbContext.payments.Add(payment);
                            paymentDbContext.paymentsSummary.Add(paymentSummary);

                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            else
            {
                if (PaymentTrials < 3)
                {
                    if (ProcessPremiumPayment(TransactionID, PaymentTrials, Amount))
                    {
                        // add to database
                        payment.Amount = Amount;
                        payment.CardHolder = CardHolder;
                        payment.CreditCardNumber = CCN;
                        payment.ExpirationDate = ExpirationDate;
                        payment.TransactionID = TransactionID;
                        payment.SecurityCode = SecurityCode;

                        paymentSummary.TransactionID = TransactionID;
                        paymentSummary.PaymentState = "Processed";

                        paymentDbContext.payments.Add(payment);
                        paymentDbContext.paymentsSummary.Add(paymentSummary);

                        return true;
                    }
                    else
                    {
                        // add to database
                        payment.Amount = Amount;
                        payment.CardHolder = CardHolder;
                        payment.CreditCardNumber = CCN;
                        payment.ExpirationDate = ExpirationDate;
                        payment.TransactionID = TransactionID;
                        payment.SecurityCode = SecurityCode;

                        paymentSummary.TransactionID = TransactionID;
                        paymentSummary.PaymentState = "Pending";

                        paymentDbContext.payments.Add(payment);
                        paymentDbContext.paymentsSummary.Add(paymentSummary);

                        return false;
                    }
                }
                else
                {
                    return false;
                }                
            }

           
        }
    }
}
