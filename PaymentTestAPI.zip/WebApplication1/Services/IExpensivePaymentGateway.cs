﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Services;

namespace WebApplication1.Controllers.Services
{
    interface IExpensivePaymentGateway
    {
        public bool ProcessExpensivePayment(int TransactionID, int PaymentTrials, decimal Amount);
    }
}
