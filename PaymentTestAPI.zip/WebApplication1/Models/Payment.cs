﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class Payment
    {
        [Required]
        [DefaultValue("")]
        [RegularExpression("^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|")]
        public string CreditCardNumber { set; get; }

        [Required]
        public string CardHolder { set; get; }

        [Required]
        public DateTime ExpirationDate { set; get; }

        [StringLength(3)]
        public string SecurityCode { set; get; }

        [Required]
        [Range(0, double.MaxValue)]
        public decimal Amount { set; get; }

        public DateTime PaymentDate { set { this.PaymentDate = DateTime.Now; } get { return PaymentDate; } }

        [Required]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PaymentID { set; get; }

        [Required]
        public int TransactionID { set; get; }
    }

    public class PaymentSummary
    {
        [Required]
        public int TransactionID { set; get; }

        [Required]
        public string PaymentState { set; get; }

        [Required]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PaymentSummaryID { set; get; }
    }
}
