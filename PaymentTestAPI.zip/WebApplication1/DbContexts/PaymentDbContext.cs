﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using WebApplication1.Models;

namespace WebApplication1.DbContexts
{
    public class PaymentDbContext : DbContext
    {
        public PaymentDbContext(DbContextOptions<PaymentDbContext> options) : base(options) { }

        public PaymentDbContext() { }

        public DbSet<Payment> payments { set; get; }
        public DbSet<PaymentSummary> paymentsSummary { set; get; }
    }
}
